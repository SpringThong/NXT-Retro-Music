#include "db.h"

#include <pthread.h>
#include <stdarg.h>
#include <sqlite3.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "defines.h"
#include "api.h"
#include "debug.h"
#include "file_utils.h"
#include "db_schema.h"
#include "db_statement.h"

static pthread_key_t connection_key;
static pthread_once_t connection_key_once = PTHREAD_ONCE_INIT;
static bool connection_key_ready;
static char* database_path;

static volatile int database_available;
static volatile int data_version;
static volatile int open_connection_count;

static int atomic_load(volatile int *ptr) {
    return __atomic_load_n(ptr, __ATOMIC_SEQ_CST);
}

static void atomic_store(volatile int *ptr, int value) {
    __atomic_store_n(ptr, value, __ATOMIC_SEQ_CST);
}

static int atomic_increment(volatile int *ptr) {
    return __atomic_add_fetch(ptr, 1, __ATOMIC_SEQ_CST);
}

static int atomic_decrement(volatile int *ptr) {
    return __atomic_sub_fetch(ptr, 1, __ATOMIC_SEQ_CST);
}

static void increment_data_version(void) {
    atomic_increment(&data_version);
}

static void connection_destroy(void* value) {
    sqlite3* database = value;
    if (!database) return;

    int result = sqlite3_close(database);
    if (result != SQLITE_OK) {
        LOG_error("[Db] failed to close connection: %s\n", sqlite3_errstr(result));
    }
    atomic_decrement(&open_connection_count);
}

static int wait_for_database_lock(void* context, int previous_attempts) {
    (void)context;
    (void)previous_attempts;
    sqlite3_sleep(5);
    return 1;
}

static void create_connection_key(void) {
    int result = pthread_key_create(&connection_key, connection_destroy);
    if (result != 0) {
        LOG_error("[Db] failed to create connection key: %s\n", strerror(result));
        return;
    }
    connection_key_ready = true;
}

static bool ensure_connection_key(void) {
    int result = pthread_once(&connection_key_once, create_connection_key);
    if (result != 0 || !connection_key_ready) {
        if (result != 0) {
            LOG_error("[Db] failed to initialize connection key: %s\n", strerror(result));
        }
        return false;
    }
    return true;
}

static sqlite3* connection(void) {
    if (!atomic_load(&database_available)) return NULL;
    if (!ensure_connection_key()) return NULL;

    sqlite3* database = pthread_getspecific(connection_key);
    if (database) return database;

    int result = sqlite3_open(database_path, &database);
    if (result != SQLITE_OK) {
        LOG_error("[Db] failed to open %s: %s\n", database_path,
                  database ? sqlite3_errmsg(database) : sqlite3_errstr(result));
        if (database) sqlite3_close(database);
        return NULL;
    }

    result = sqlite3_busy_handler(database, wait_for_database_lock, NULL);
    if (result != SQLITE_OK) {
        LOG_error("[Db] failed to set busy handler: %s\n", sqlite3_errmsg(database));
        sqlite3_close(database);
        return NULL;
    }

    DbStatement statement;

    bool journal_ok = false;
    DbStatement_begin(&statement, database, "PRAGMA journal_mode=WAL");
    if (DbStatement_step(&statement)) {
        const char* journal_mode = DbStatement_get_text(&statement, 0);
        journal_ok = journal_mode && strcmp(journal_mode, "wal") == 0;
    }
    DbStatement_close(&statement);

    if (!journal_ok || !statement.ok) {
        LOG_error("[Db] failed to enable WAL: %s\n", sqlite3_errmsg(database));
        sqlite3_close(database);
        return NULL;
    }

    DbStatement_exec(&statement, database, "PRAGMA wal_autocheckpoint=0");
    if (!statement.ok) {
        LOG_error("[Db] failed to disable automatic checkpoints: %s\n",
                  statement.errmsg);
        sqlite3_close(database);
        return NULL;
    }

    DbStatement_exec(&statement, database, "PRAGMA foreign_keys=ON");
    if (!statement.ok) {
        LOG_error("[Db] failed to enable foreign keys: %s\n", statement.errmsg);
        sqlite3_close(database);
        return NULL;
    }

    result = pthread_setspecific(connection_key, database);
    if (result != 0) {
        LOG_error("[Db] failed to store connection: %s\n", strerror(result));
        sqlite3_close(database);
        return NULL;
    }
    atomic_increment(&open_connection_count);
    return database;
}

static void close_current_connection(void) {
    if (!connection_key_ready) return;

    sqlite3* database = pthread_getspecific(connection_key);
    if (!database) return;

    pthread_setspecific(connection_key, NULL);
    connection_destroy(database);
}

static void disable_database(void) {
    atomic_store(&database_available, 0);
    close_current_connection();
}

static bool execute(sqlite3* database, const char* sql) {
    if (!database) {
        LOG_error("[Db] SQL failed: %s: no database\n", sql ? sql : "(null)");
        return false;
    }

    char* error = NULL;
    int result = sqlite3_exec(database, sql, NULL, NULL, &error);
    if (result == SQLITE_OK) {
        sqlite3_free(error);
        return true;
    }

    LOG_error("[Db] SQL failed: %s: %s\n", sql ? sql : "(null)",
              error ? error : sqlite3_errmsg(database));
    sqlite3_free(error);
    return false;
}

static bool read_schema_version(sqlite3* database, int* version) {
    DbStatement statement;
    DbStatement_begin(&statement, database, "PRAGMA user_version");
    if (DbStatement_step(&statement)) {
        *version = DbStatement_get_int(&statement, 0);
    }
    DbStatement_close(&statement);

    if (!statement.ok) {
        LOG_error("[Db] failed to read schema version: %s\n", statement.errmsg);
        return false;
    }

    return true;
}

static bool validate_steps(const DbMigrationStep* steps,
                           size_t* step_count, int* schema_version) {
    size_t index = 0;
    for (; steps[index].version >= 0; index++) {
        const DbMigrationStep* step = &steps[index];
        if (step->version != (int)index + 1) {
            LOG_error("[Db] invalid migration step %zu\n", index);
            return false;
        }

        bool valid_sql = step->type == DB_MIGRATION_SQL && step->sql;
        bool valid_function = step->type == DB_MIGRATION_FUNCTION &&
                              step->function;
        bool valid_text = step->text && step->text[0] != '\0';

        bool valid_action = (valid_sql || valid_function) && valid_text;
        if (!valid_action) {
            LOG_error("[Db] invalid migration step %zu\n", index);
            return false;
        }
    }
    *step_count = index;
    *schema_version = (int)index;
    return true;
}

static bool run_step(sqlite3* database, const DbMigrationStep* step) {
    char pragma[64];
    snprintf(pragma, sizeof(pragma), "PRAGMA user_version = %d", step->version);

    bool success = true;

    // begin/execute/update_version/commit
    success = success && Db_begin();
    if (step->type == DB_MIGRATION_SQL) {
        success = success && execute(database, step->sql);
    } else {
        success = success && step->function(database);
    }
    success = success && execute(database, pragma);
    success = success && Db_commit();
    if (!success) {
        Db_rollback();
        LOG_error("[Db] failed migration step %d \"%s\"\n", step->version,
                  step->text);
    }
    return success;
}

static bool migrate(sqlite3* database) {
    int version = 0;
    if (!read_schema_version(database, &version)) return false;
    DbMigrationStep* steps = DbSchema_getSteps();
    if (!steps) return false;
    size_t step_count = 0;
    int schema_version = 0;
    if (!validate_steps(steps, &step_count, &schema_version)) {
        free(steps);
        return false;
    }
    if (version < 0 || version > schema_version) {
        LOG_error("[Db] database schema version %d is newer than binary version %d\n",
                  version, schema_version);
        free(steps);
        return false;
    }

    for (size_t index = (size_t)version; index < step_count; index++) {
        if (!run_step(database, &steps[index])) {
            break;
        }
        version = steps[index].version;
    }
    bool success = version == schema_version;
    free(steps);
    return success;
}

bool Db_init(void) {
    if (!userdata_mkdir("")) {
        LOG_error("[Db] failed to create the app data directory\n");
        return false;
    }

    char* path = userdata_path("music-player.db");
    if (!path) {
        LOG_error("[Db] failed to allocate the database path\n");
        return false;
    }

    bool result = Db_initInternal(path);
    free(path);
    return result;
}

bool Db_initInternal(const char* path) {
    if (!path || !path[0]) {
        LOG_error("[Db] database path is empty\n");
        return false;
    }

    Db_quit();
    if (!ensure_connection_key()) return false;

    database_path = strdup(path);
    if (!database_path) {
        LOG_error("[Db] failed to allocate the database path\n");
        return false;
    }

    atomic_store(&data_version, 0);
    atomic_store(&database_available, 1);
    if (!connection()) {
        LOG_error("[Db] database is unavailable\n");
        disable_database();
        free(database_path);
        database_path = NULL;
        return false;
    }

    sqlite3* database = pthread_getspecific(connection_key);
    if (!migrate(database)) {
        disable_database();
        free(database_path);
        database_path = NULL;
        return false;
    }
    return true;
}

void Db_quit(void) {
    atomic_store(&database_available, 0);
    close_current_connection();

    int count = atomic_load(&open_connection_count);
    if (count != 0) {
        LOG_error("[Db] %d thread connection(s) remain open\n", count);
    }

    free(database_path);
    database_path = NULL;
}

bool Db_isAvailable(void) {
    return atomic_load(&database_available) != 0;
}

bool Db_begin(void) {
    return execute(connection(), "BEGIN");
}

bool Db_commit(void) {
    if (!execute(connection(), "COMMIT")) return false;

    increment_data_version();
    return true;
}

bool Db_rollback(void) {
    return execute(connection(), "ROLLBACK");
}

bool Db_execute(const char* sql) {
    if (!sql || !sql[0]) return false;

    if (!execute(connection(), sql)) return false;

    increment_data_version();
    return true;
}

int Db_dataVersion(void) {
    return atomic_load(&data_version);
}

bool Db_resultIsCurrent(const DbResult* result) {
    if (!result) return false;
    return result->data_version == Db_dataVersion();
}

void Db_freeResult(void* value) {
    if (!value) return;

    DbResult* result = value;
    if (!result->free) {
        LOG_error("[Db] result has no free function\n");
        return;
    }
    result->free(value);
}

// Snapshot reads

// Starts a savepoint. Outside a transaction it starts a read transaction, thus each query
// until the release sees the same data. Returns false when the savepoint did not start; the
// connection then cannot read either.
static bool begin_snapshot(const char* name) {
    char sql[64];
    snprintf(sql, sizeof(sql), "SAVEPOINT %s", name);
    return execute(connection(), sql);
}

static void end_snapshot(const char* name) {
    char sql[64];
    snprintf(sql, sizeof(sql), "RELEASE %s", name);
    execute(connection(), sql);
}

// Settings

static void free_settings_result(DbSettingsResult* result) {
    for (int index = 0; index < result->count; index++) {
        free(result->items[index].name);
        free(result->items[index].string_value);
    }
    free(result->items);
    free(result);
}

static DbSettingsResult* allocate_settings_result(void) {
    DbSettingsResult* result = calloc(1, sizeof(*result));
    if (result) {
        result->base.data_version = Db_dataVersion();
        result->base.free = (DbResultDestructor) free_settings_result;
    }
    return result;
}

// Returns -1 for a type name that is not known.
static DbSettingType setting_type_from_name(const char* name) {
    if (!name) return (DbSettingType) -1;
    if (strcmp(name, "int") == 0) return DB_SETTING_INT;
    if (strcmp(name, "bool") == 0) return DB_SETTING_BOOL;
    if (strcmp(name, "string") == 0) return DB_SETTING_STRING;
    return (DbSettingType) -1;
}

DbSettingsResult* Db_readSettings(void) {
    DbSettingsResult* result = allocate_settings_result();
    if (!result) return NULL;

    if (!begin_snapshot("read_settings")) {
        LOG_error("[Db] failed to read settings: no snapshot\n");
        return result;
    }

    DbStatement statement;
    int count = DbStatement_query_int(&statement, connection(),
                                      "SELECT COUNT(*) FROM settings");

    if (statement.ok && count > 0) {
        DbStatement_begin(&statement, connection(), "SELECT name, type, value FROM settings");
        result->items = DbStatement_calloc(&statement, (size_t)count * sizeof(*result->items));
        for (int row = 0; row < count && DbStatement_step(&statement); row++) {
            const char* type_name = DbStatement_get_text(&statement, 1);
            DbSettingType type = setting_type_from_name(type_name);
            if (type == (DbSettingType) -1) {
                if (statement.ok) {
                    LOG_warn("[Db] skipped setting %s with unknown type %s\n",
                             DbStatement_get_text(&statement, 0), type_name);
                }
                continue;
            }

            DbSetting* setting = &result->items[result->count++];
            setting->name = DbStatement_dup_text(&statement, 0);
            setting->type = type;
            switch (type) {
                case DB_SETTING_INT:
                    setting->int_value = DbStatement_get_int(&statement, 2);
                    break;
                case DB_SETTING_BOOL: {
                    const char* value = DbStatement_get_text(&statement, 2);
                    setting->bool_value = value && strcmp(value, "true") == 0;
                    break;
                }
                case DB_SETTING_STRING:
                    setting->string_value = DbStatement_dup_text(&statement, 2);
                    break;
            }
        }
        DbStatement_close(&statement);
    }

    end_snapshot("read_settings");

    if (!statement.ok) {
        free_settings_result(result);
        result = allocate_settings_result();
        LOG_error("[Db] failed to read settings: %s\n", statement.errmsg);
    }
    return result;
}

static bool save_setting(const char* name, const char* type,
                         int int_value, const char* string_value) {
    if (!name || !type) return false;

    DbStatement statement;
    DbStatement_begin(&statement, connection(),
                      "INSERT OR REPLACE INTO settings (name, type, value) "
                      "VALUES (?, ?, ?)");
    DbStatement_bind_text(&statement, 1, name);
    DbStatement_bind_text(&statement, 2, type);
    if (string_value) {
        DbStatement_bind_text(&statement, 3, string_value);
    } else {
        DbStatement_bind_int(&statement, 3, int_value);
    }
    DbStatement_step(&statement);
    DbStatement_close(&statement);

    if (!statement.ok) {
        LOG_error("[Db] failed to save setting %s: %s\n",
                  name, statement.errmsg);
        return false;
    }

    increment_data_version();
    return true;
}

bool Db_saveIntSetting(const char* name, int value) {
    return save_setting(name, "int", value, NULL);
}

bool Db_saveBoolSetting(const char* name, bool value) {
    return save_setting(name, "bool", 0, value ? "true" : "false");
}

bool Db_saveStringSetting(const char* name, const char* value) {
    if (!value) return false;
    return save_setting(name, "string", 0, value);
}
