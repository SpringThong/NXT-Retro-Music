#include "msettings.h"
#include "displaycal.h"

// desktop
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
//#include <sys/mman.h>
//#include <sys/ioctl.h>
//#include <errno.h>
//#include <sys/stat.h>
//#include <dlfcn.h>
#include <string.h>

// Legacy MinUI settings
typedef struct SettingsV3 {
	int version; // future proofing
	int brightness;
	int headphones;
	int speaker;
	int mute;
	int unused[2];
	int jack;
} SettingsV3;

// First NextUI settings format
typedef struct SettingsV4 {
	int version; // future proofing
	int brightness;
	int colortemperature; // 0-20
	int headphones;
	int speaker;
	int mute;
	int unused[2];
	int jack; 
} SettingsV4;

// Current NextUI settings format
typedef struct SettingsV5 {
	int version; // future proofing
	int brightness;
	int colortemperature;
	int headphones;
	int speaker;
	int mute;
	int unused[2]; // for future use
	// NOTE: doesn't really need to be persisted but still needs to be shared
	int jack; 
} SettingsV5;


// Third NextUI settings format
typedef struct SettingsV6 {
	int version; // future proofing
	int brightness;
	int colortemperature;
	int headphones;
	int speaker;
	int mute;
	int contrast;
	int saturation;
	int exposure;
	int unused[2]; // for future use
	// NOTE: doesn't really need to be persisted but still needs to be shared
	int jack; 
} SettingsV6;

typedef struct SettingsV7 {
	int version; // future proofing
	int brightness;
	int colortemperature;
	int headphones;
	int speaker;
	int mute;
	int contrast;
	int saturation;
	int exposure;
	int mutedbrightness;
	int mutedcolortemperature;
	int mutedcontrast;
	int mutedsaturation;
	int mutedexposure;
	int unused[2]; // for future use
	// NOTE: doesn't really need to be persisted but still needs to be shared
	int jack; 
} SettingsV7;

typedef struct SettingsV8 {
	int version; // future proofing
	int brightness;
	int colortemperature;
	int headphones;
	int speaker;
	int mute;
	int contrast;
	int saturation;
	int exposure;
	int toggled_brightness;
	int toggled_colortemperature;
	int toggled_contrast;
	int toggled_saturation;
	int toggled_exposure;
	int toggled_volume;
	int unused[2]; // for future use
	// NOTE: doesn't really need to be persisted but still needs to be shared
	int jack; 
} SettingsV8;

typedef struct SettingsV9 {
	int version; // future proofing
	int brightness;
	int colortemperature;
	int headphones;
	int speaker;
	int mute;
	int contrast;
	int saturation;
	int exposure;
	int toggled_brightness;
	int toggled_colortemperature;
	int toggled_contrast;
	int toggled_saturation;
	int toggled_exposure;
	int toggled_volume;
	int disable_dpad_on_mute;
	int emulate_joystick_on_mute;
	int turbo_a;
	int turbo_b;
	int turbo_x;
	int turbo_y;
	int turbo_l1;
	int turbo_l2;
	int turbo_r1;
	int turbo_r2;
	int unused[2]; // for future use
	// NOTE: doesn't really need to be persisted but still needs to be shared
	int jack; 
} SettingsV9;

typedef struct SettingsV10 {
	int version; // future proofing
	int brightness;
	int colortemperature;
	int headphones;
	int speaker;
	int mute;
	int contrast;
	int saturation;
	int exposure;
	int toggled_brightness;
	int toggled_colortemperature;
	int toggled_contrast;
	int toggled_saturation;
	int toggled_exposure;
	int toggled_volume;
	int disable_dpad_on_mute;
	int emulate_joystick_on_mute;
	int turbo_a;
	int turbo_b;
	int turbo_x;
	int turbo_y;
	int turbo_l1;
	int turbo_l2;
	int turbo_r1;
	int turbo_r2;
	int unused[2]; // for future use
	// NOTE: doesn't really need to be persisted but still needs to be shared
	int jack;
	int displaycal_enabled;
	int displaycal_red_gain;
	int displaycal_green_gain;
	int displaycal_blue_gain;
} SettingsV10;

// When incrementing SETTINGS_VERSION, update the Settings typedef and add
// backwards compatibility to InitSettings!
#define SETTINGS_VERSION 10
typedef SettingsV10 Settings;
static Settings DefaultSettings = {
	.version = SETTINGS_VERSION,
	.brightness = SETTINGS_DEFAULT_BRIGHTNESS,
	.colortemperature = SETTINGS_DEFAULT_COLORTEMP,
	.headphones = SETTINGS_DEFAULT_HEADPHONE_VOLUME,
	.speaker = SETTINGS_DEFAULT_VOLUME,
	.mute = 0,
	.contrast = SETTINGS_DEFAULT_CONTRAST,
	.saturation = SETTINGS_DEFAULT_SATURATION,
	.exposure = SETTINGS_DEFAULT_EXPOSURE,
	.toggled_brightness = SETTINGS_DEFAULT_MUTE_NO_CHANGE,
	.toggled_colortemperature = SETTINGS_DEFAULT_MUTE_NO_CHANGE,
	.toggled_contrast = SETTINGS_DEFAULT_MUTE_NO_CHANGE,
	.toggled_saturation = SETTINGS_DEFAULT_MUTE_NO_CHANGE,
	.toggled_exposure = SETTINGS_DEFAULT_MUTE_NO_CHANGE,
	.toggled_volume = 0, // mute is default
	.disable_dpad_on_mute = 0,
	.emulate_joystick_on_mute = 0,
	.turbo_a = 0,
	.turbo_b = 0,
	.turbo_x = 0,
	.turbo_y = 0,
	.turbo_l1 = 0,
	.turbo_l2 = 0,
	.turbo_r1 = 0,
	.turbo_r2 = 0,
	.jack = 0,
	.displaycal_enabled = DISPLAYCAL_DEFAULT_ENABLED,
	.displaycal_red_gain = DISPLAYCAL_DEFAULT_RED_GAIN,
	.displaycal_green_gain = DISPLAYCAL_DEFAULT_GREEN_GAIN,
	.displaycal_blue_gain = DISPLAYCAL_DEFAULT_BLUE_GAIN,
};
static Settings* msettings;

static char SettingsPath[256];

static inline void applyDisplayCalSettings(void);

///////////////////////////////////////

int peekVersion(const char *filename) {
	int version = 0;
	FILE *file = fopen(filename, "r");
	if (file) {
		fread(&version, sizeof(int), 1, file);
		fclose(file);
	}
	return version;
}

void InitSettings(void){
	// We are not really using them, but we should be able to debug them
	sprintf(SettingsPath, "%s/msettings.bin", getenv("USERDATA_PATH"));
	//sprintf(SettingsPath, "%s/msettings.bin", SDCARD_PATH "/.userdata");
	msettings = (Settings*)malloc(sizeof(Settings));
	
	int version = peekVersion(SettingsPath);
	if(version > 0) {
		// fopen file pointer
		int fd = open(SettingsPath, O_RDONLY);
		if(fd) {
			if (version == SETTINGS_VERSION) {
				read(fd, msettings, sizeof(Settings));
			}
			else {
				// initialize with defaults
				memcpy(msettings, &DefaultSettings, sizeof(Settings));
				
				// overwrite with migrated data
				if(version==9) {
					printf("Found settings v9.\n");
					SettingsV9 old;
					read(fd, &old, sizeof(SettingsV9));

					memcpy(msettings, &old, sizeof(SettingsV9));
					msettings->version = SETTINGS_VERSION;
				}
				else if(version==8) {
					printf("Found settings v8.\n");
					SettingsV8 old;
					read(fd, &old, sizeof(SettingsV8));

					msettings->toggled_volume = old.toggled_volume;

					msettings->toggled_brightness = old.toggled_brightness;
					msettings->toggled_colortemperature = old.toggled_colortemperature;
					msettings->toggled_contrast = old.toggled_contrast;
					msettings->toggled_exposure = old.toggled_exposure;
					msettings->toggled_saturation = old.toggled_saturation;
					
					msettings->saturation = old.saturation;
					msettings->contrast = old.contrast;
					msettings->exposure = old.exposure;

					msettings->colortemperature = old.colortemperature;

					msettings->brightness = old.brightness;
					msettings->headphones = old.headphones;
					msettings->speaker = old.speaker;
					msettings->mute = old.mute;
					msettings->jack = old.jack;
				}
				else if(version==7) {
					printf("Found settings v7.\n");
					SettingsV7 old;
					read(fd, &old, sizeof(SettingsV7));

					msettings->toggled_brightness = old.mutedbrightness;
					msettings->toggled_colortemperature = old.mutedcolortemperature;
					msettings->toggled_contrast = old.mutedcontrast;
					msettings->toggled_exposure = old.mutedexposure;
					msettings->toggled_saturation = old.mutedsaturation;

					msettings->saturation = old.saturation;
					msettings->contrast = old.contrast;
					msettings->exposure = old.exposure;

					msettings->colortemperature = old.colortemperature;

					msettings->brightness = old.brightness;
					msettings->headphones = old.headphones;
					msettings->speaker = old.speaker;
					msettings->mute = old.mute;
					msettings->jack = old.jack;
				}
				else if(version==6) {
					printf("Found settings v6.\n");
					SettingsV6 old;
					read(fd, &old, sizeof(SettingsV6));
					
					msettings->saturation = old.saturation;
					msettings->contrast = old.contrast;
					msettings->exposure = old.exposure;

					msettings->colortemperature = old.colortemperature;

					msettings->brightness = old.brightness;
					msettings->headphones = old.headphones;
					msettings->speaker = old.speaker;
					msettings->mute = old.mute;
					msettings->jack = old.jack;
				}
				else if(version==5) {
					printf("Found settings v5.\n");
					SettingsV5 old;
					read(fd, &old, sizeof(SettingsV5));

					msettings->colortemperature = old.colortemperature;

					msettings->brightness = old.brightness;
					msettings->headphones = old.headphones;
					msettings->speaker = old.speaker;
					msettings->mute = old.mute;
					msettings->jack = old.jack;
				}
				else if(version==4) {
					printf("Found settings v4.\n");
					SettingsV4 old;
					read(fd, &old, sizeof(SettingsV4));

					// colortemp was 0-20 here
					msettings->colortemperature = old.colortemperature * 2;

					msettings->brightness = old.brightness;
					msettings->headphones = old.headphones;
					msettings->speaker = old.speaker;
					msettings->mute = old.mute;
					msettings->jack = old.jack;
				}
				else if(version==3) {
					printf("Found settings v3.\n");
					SettingsV3 old;
					read(fd, &old, sizeof(SettingsV3));

					msettings->brightness = old.brightness;
					msettings->headphones = old.headphones;
					msettings->speaker = old.speaker;
					msettings->mute = old.mute;
					msettings->jack = old.jack;
				}
				else {
					printf("Found unsupported settings version: %i.\n", version);
				}
			}

			close(fd);
		}
		else {
			printf("Unable to read settings, using defaults\n");
			// load defaults
			memcpy(msettings, &DefaultSettings, sizeof(Settings));
		}
	}
	else {
		printf("No settings found, using defaults\n");
		// load defaults
		memcpy(msettings, &DefaultSettings, sizeof(Settings));
	}

	applyDisplayCalSettings();
}
static inline void SaveSettings(void) {
	FILE *file = fopen(SettingsPath, "w");
	if (file) {
		fwrite(msettings, sizeof(Settings), 1, file);
		fclose(file);
	}
}
static inline void applyDisplayCalSettings(void) {
	if (msettings->displaycal_enabled)
		SetRawDisplayCal(1, msettings->displaycal_red_gain, msettings->displaycal_green_gain, msettings->displaycal_blue_gain);
}
void QuitSettings(void){
	SaveSettings();
	// dealloc settings
	free(msettings);
	msettings = NULL;
}
int InitializedSettings(void){
	return msettings != NULL;
}

// not implemented here

int GetBrightness(void) { return 0; }
int GetColortemp(void) { return 0; }
int GetContrast(void) { return 0; }
int GetSaturation(void) { return 0; }
int GetExposure(void) { return 0; }
int GetDisplayCalEnabled(void) { return msettings->displaycal_enabled; }
int GetDisplayCalRedGain(void) { return msettings->displaycal_red_gain; }
int GetDisplayCalGreenGain(void) { return msettings->displaycal_green_gain; }
int GetDisplayCalBlueGain(void) { return msettings->displaycal_blue_gain; }
int GetVolume(void) { return 0; }

int GetMutedBrightness(void) { return 0; }
int GetMutedColortemp(void) { return 0; }
int GetMutedContrast(void) { return 0; }
int GetMutedSaturation(void) { return 0; }
int GetMutedExposure(void) { return 0; }
int GetMutedVolume(void) { return 0; }
int GetMuteDisablesDpad(void) { return 0; }
int GetMuteEmulatesJoystick(void) { return 0; }
int GetMuteTurboA(void) { return 0; }
int GetMuteTurboB(void) { return 0; }
int GetMuteTurboX(void) { return 0; }
int GetMuteTurboY(void) { return 0; }
int GetMuteTurboL1(void) { return 0; }
int GetMuteTurboL2(void) { return 0; }
int GetMuteTurboR1(void) { return 0; }
int GetMuteTurboR2(void) { return 0; }

void SetMutedBrightness(int value){}
void SetMutedColortemp(int value){}
void SetMutedContrast(int value){}
void SetMutedSaturation(int value){}
void SetMutedExposure(int value){}
void SetMutedVolume(int value){}
void SetMuteDisablesDpad(int value) {}
void SetMuteEmulatesJoystick(int value) {}
void SetMuteTurboA(int value) {}
void SetMuteTurboB(int value) {}
void SetMuteTurboX(int value) {}
void SetMuteTurboY(int value) {}
void SetMuteTurboL1(int value) {}
void SetMuteTurboL2(int value) {}
void SetMuteTurboR1(int value) {}
void SetMuteTurboR2(int value) {}

void SetRawBrightness(int value) {}
void SetRawDisplayCal(int enabled, int red_gain, int green_gain, int blue_gain) {
	printf("SetRawDisplayCal(%i,%i,%i,%i)\n", enabled, red_gain, green_gain, blue_gain); fflush(stdout);
}
void SetRawVolume(int value){}

void SetBrightness(int value) {}
void SetColortemp(int value) {}
void SetContrast(int value) {}
void SetSaturation(int value) {}
void SetExposure(int value) {}
void SetDisplayCalEnabled(int is_enabled) {
	int was_enabled = msettings->displaycal_enabled;
	is_enabled = (is_enabled != 0);
	msettings->displaycal_enabled = is_enabled;

	// Disabling only needs raw writes when we are turning an active LUT off.
	if (is_enabled)
		applyDisplayCalSettings();
	else if (was_enabled)
		SetRawDisplayCal(0, msettings->displaycal_red_gain, msettings->displaycal_green_gain, msettings->displaycal_blue_gain);
	SaveSettings();
}
void SetDisplayCalRedGain(int value) {
	value = DisplayCal_clampGainValue(value);
	msettings->displaycal_red_gain = value;
	applyDisplayCalSettings();
	SaveSettings();
}
void SetDisplayCalGreenGain(int value) {
	value = DisplayCal_clampGainValue(value);
	msettings->displaycal_green_gain = value;
	applyDisplayCalSettings();
	SaveSettings();
}
void SetDisplayCalBlueGain(int value) {
	value = DisplayCal_clampGainValue(value);
	msettings->displaycal_blue_gain = value;
	applyDisplayCalSettings();
	SaveSettings();
}
void SetVolume(int value) {}

int GetJack(void) { return 0; }
void SetJack(int value) {}

int GetAudioSink(void) { return 0; }
void SetAudioSink(int value) {}

int GetHDMI(void) { return 0; }
void SetHDMI(int value) {}

int GetMute(void) { return 0; }
