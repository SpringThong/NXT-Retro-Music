// tg5040

#ifndef PLATFORM_H
#define PLATFORM_H

///////////////////////////////

#ifdef SDL
#	include "sdl.h"
#endif

///////////////////////////////

extern int is_brick;
extern int is_brickpro;

///////////////////////////////

#define BUTTON_UP		BUTTON_NA
#define BUTTON_DOWN		BUTTON_NA
#define BUTTON_LEFT		BUTTON_NA
#define BUTTON_RIGHT	BUTTON_NA

#define BUTTON_SELECT	BUTTON_NA
#define BUTTON_START	BUTTON_NA

#define BUTTON_A		BUTTON_NA
#define BUTTON_B		BUTTON_NA
#define BUTTON_X		BUTTON_NA
#define BUTTON_Y		BUTTON_NA

#define BUTTON_L1		BUTTON_NA
#define BUTTON_R1		BUTTON_NA
#define BUTTON_L2		BUTTON_NA
#define BUTTON_R2		BUTTON_NA
#define BUTTON_L3		BUTTON_NA
#define BUTTON_R3		BUTTON_NA
#define BUTTON_L4		BUTTON_NA
#define BUTTON_R4		BUTTON_NA

#define BUTTON_MENU		BUTTON_NA
#define BUTTON_MENU_ALT	BUTTON_NA
#define	BUTTON_POWER	116 // BUTTON_NA
#define	BUTTON_PLUS		BUTTON_NA
#define	BUTTON_MINUS	BUTTON_NA

///////////////////////////////

#define CODE_UP			CODE_NA
#define CODE_DOWN		CODE_NA
#define CODE_LEFT		CODE_NA
#define CODE_RIGHT		CODE_NA

#define CODE_SELECT		CODE_NA
#define CODE_START		CODE_NA

#define CODE_A			CODE_NA
#define CODE_B			CODE_NA
#define CODE_X			CODE_NA
#define CODE_Y			CODE_NA

#define CODE_L1			CODE_NA
#define CODE_R1			CODE_NA
#define CODE_L2			CODE_NA
#define CODE_R2			CODE_NA
#define CODE_L3			CODE_NA
#define CODE_R3			CODE_NA
#define CODE_L4         CODE_NA
#define CODE_R4         CODE_NA

#define CODE_MENU		CODE_NA
#define CODE_POWER		102

#define CODE_PLUS		128
#define CODE_MINUS		129

///////////////////////////////
						// HATS
#define JOY_UP			JOY_NA
#define JOY_DOWN		JOY_NA
#define JOY_LEFT		JOY_NA
#define JOY_RIGHT		JOY_NA

#define JOY_SELECT		6
#define JOY_START		7

// TODO: these ended up swapped in the first public release of stock :sob:
#define JOY_A			1
#define JOY_B			0
#define JOY_X			3
#define JOY_Y			2

#define JOY_L1			4
#define JOY_R1			5
#define JOY_L2			JOY_NA
#define JOY_R2			JOY_NA
#define JOY_L3			(is_brick||is_brickpro?9:JOY_NA)
#define JOY_R3			(is_brick||is_brickpro?10:JOY_NA)
#define JOY_L4          (is_brickpro?11:JOY_NA)
#define JOY_R4          (is_brickpro?12:JOY_NA)

#define JOY_MENU		8
#define JOY_MENU_ALT    (is_brickpro?15:JOY_NA)
#define JOY_POWER		102
#define JOY_PLUS		(is_brick||is_brickpro?14:128)
#define JOY_MINUS		(is_brick||is_brickpro?13:129)

///////////////////////////////
// USER-ASSIGNABLE BUTTONS
#define BTN_FN1			(is_brick?BTN_L3:(is_brickpro?BTN_L4:BTN_NONE))
#define BTN_FN2			(is_brick?BTN_R3:(is_brickpro?BTN_R4:BTN_NONE))
#define BTN_FN1_NAME	(is_brick?"L3":(is_brickpro?"L4":""))
#define BTN_FN2_NAME	(is_brick?"R3":(is_brickpro?"R4":""))
#define BTN_FN3			(is_brickpro?BTN_HOME:BTN_NONE)
#define BTN_FN3_NAME	(is_brickpro?"HOME":"")

///////////////////////////////

#define AXIS_L2			2 // ABSZ
#define AXIS_R2			5 // RABSZ

#define AXIS_LX			0 // ABS_X, -30k (left) to 30k (right)
#define AXIS_LY			1 // ABS_Y, -30k (up) to 30k (down)
#define AXIS_RX			3 // ABS_RX, -30k (left) to 30k (right)
#define AXIS_RY			4 // ABS_RY, -30k (up) to 30k (down)

///////////////////////////////

#define BTN_RESUME			BTN_X
#define BTN_SLEEP 			BTN_POWER
#define BTN_WAKE 			BTN_POWER
#define BTN_MOD_VOLUME 		BTN_NONE
#define BTN_MOD_BRIGHTNESS 	BTN_MENU
#define BTN_MOD_COLORTEMP 	BTN_SELECT
#define BTN_MOD_PLUS 		BTN_PLUS
#define BTN_MOD_MINUS 		BTN_MINUS

///////////////////////////////

#define FIXED_SCALE 	(is_brick||is_brickpro?3:2)
#define FIXED_WIDTH		(is_brick||is_brickpro?1024:1280)
#define FIXED_HEIGHT	(is_brick||is_brickpro?768:720)
#define FIXED_BPP		2
#define FIXED_DEPTH		(FIXED_BPP * 8)
#define FIXED_PITCH		(FIXED_WIDTH * FIXED_BPP)
#define FIXED_SIZE		(FIXED_PITCH * FIXED_HEIGHT)

///////////////////////////////

#define MAIN_ROW_COUNT (is_brick||is_brickpro ? 7 : 10)
#define QUICK_SWITCHER_COUNT (is_brick||is_brickpro ? 3 : 4)
#define PADDING (is_brick||is_brickpro ? 5 : 10)

///////////////////////////////

#define SDCARD_PATH "/mnt/SDCARD"
#define MUTE_VOLUME_RAW 0

// this should be set to the devices native screen refresh rate
#define SCREEN_FPS 60.235

#define MAX_LIGHTS 5

///////////////////////////////

#endif
